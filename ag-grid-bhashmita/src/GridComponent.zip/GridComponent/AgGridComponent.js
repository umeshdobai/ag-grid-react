import React, { Component } from "react";
import { AgGridReact } from "ag-grid-react";
import "ag-grid-community/dist/styles/ag-grid.css";
import "ag-grid-community/dist/styles/ag-theme-fresh.css";
import "ag-grid-enterprise";
import { Icon, Input, Button, Dropdown, Menu, Checkbox } from "antd";
import Paper from "@material-ui/core/Paper";
import { columnDefs, rowData, columnTitle } from "./GridData";
import CustomHeader from "./CustomHeader";
import PartialMatchFilter from "./PartialMatchFilter";
let minRowHeight = 25;
let currentRowHeight = minRowHeight;
let filterType = "everyone";

class AgGridComponent extends Component {
	constructor(props) {
		super(props);

		this.state = {
			getRowHeight: function() {
				return currentRowHeight;
			},
			defaultColDef: {
				resizable: true,
				sortable: true,
				headerComponentParams: { menuIcon: "filter", value: filterType },
				filter: true,
				menuTabs: ["filterMenuTab"]
			},
			columnTitle: columnTitle,
			columnInfo: [],
			columnData: columnDefs,
			checkedCols: [],
			domLayout: "autoHeight",
			rowDataCount: rowData.length,
			frameworkComponents: {
				agColumnHeader: CustomHeader,
				partialMatchFilter: PartialMatchFilter
			}
		};
	}

	externalFilterChanged(newValue) {
		console.log(newValue, "externalFilterChanged");
		// filterType = newValue;
		this.props.api.onFilterChanged();
	}

	onGridReady = params => {
		this.gridApi = params.api;
		this.gridColumnApi = params.columnApi;

		minRowHeight = 30;
		currentRowHeight = minRowHeight;
		if (!rowData) {
			params.api.showNoRowsOverlay();
		}
		params.api.sizeColumnsToFit();
	};

	onGridSizeChanged(params) {
		var gridHeight = document.getElementsByClassName("ag-body-viewport")[0]
			.offsetHeight;
		var renderedRows = params.api.getRenderedNodes();
		if (renderedRows.length * minRowHeight >= gridHeight) {
			if (currentRowHeight !== minRowHeight) {
				currentRowHeight = minRowHeight;
				params.api.resetRowHeights();
			}
		} else {
			currentRowHeight = Math.floor(gridHeight / renderedRows.length);
			params.api.resetRowHeights();
		}
	}

	onClick = ({ key }) => {
		let colKey = key;
		let removedCols = this.state.checkedCols.includes(colKey);
		if (removedCols) {
			let column = this.state.columnInfo.filter(
				col => col.headerName === colKey
			);
			let index = this.state.checkedCols.findIndex(col => col === key);
			this.state.checkedCols.splice(index, 1);
			this.state.columnData.push(column[0]);
		} else {
			this.state.checkedCols.push(colKey);
			let columnIndex = columnDefs.findIndex(col => {
				return col.headerName === key;
			});
			const filteredColumn = this.state.columnData.splice(columnIndex, 1);
			this.state.columnInfo.push(filteredColumn[0]);
			this.setState({
				columnData: this.state.columnData,
				columnInfo: this.state.columnInfo
			});
		}
		this.gridApi.setColumnDefs(this.state.columnData);
		this.setState({
			checkedCols: this.state.checkedCols,
			columnData: this.state.columnData
		});
	};

	menu = () => {
		return (
			<Menu onClick={this.onClick}>
				{this.state.columnTitle.map((col, index) => (
					<Menu.Item key={col.name}>
						<Checkbox
							checked={this.state.checkedCols.find(
								checks => checks === col.name
							)}
						></Checkbox>
						{col.name}
					</Menu.Item>
				))}
			</Menu>
		);
	};

	clearFilter = () => {
		this.gridApi.setFilterModel(null);
		this.gridApi.onFilterChanged();
	};

	isExternalFilterPresent() {
		return filterType != "everyone";
	}

	doesExternalFilterPass(node) {
		console.log(node, "node");
		// switch (filterType) {
		// 	case "lesserThan":
		// 		return node.data.age < 30;
		// 	case "equals":
		// 		return node.data.age >= 30 && node.data.age <= 50;
		// 	case "greaterThan":
		// 		return node.data.age > 50;
		// 	default:
		// 		return true;
		// }
	}

	render() {
		return (
			<div style={{ width: "100%", height: "100%" }}>
				<Paper className="paper-style" elevation={3}>
					<div
						style={{ height: "100%", display: "flex", flexDirection: "column" }}
					>
						<div className="btn-container">
							<div style={{ alignItems: "start" }}>
								<span>Row Count ={this.state.rowDataCount}</span>
							</div>
							<div>
								<span className="button-group">
									<Button>Refresh</Button>
								</span>
								<span className="button-group">
									<Button>Clear Find</Button>
								</span>
								<span className="button-group">
									<Button onClick={this.clearFilter}>Clear filter</Button>
								</span>
								<Dropdown.Button
									className="button-group"
									trigger={["click"]}
									overlay={this.menu}
									icon={<Icon type="down" />}
								>
									Show/hide columns
								</Dropdown.Button>
							</div>
						</div>
					</div>

					<div
						id="myGrid"
						className="ag-theme-fresh"
						style={{ width: "100%", height: "100%", overflow: "scroll" }}
					>
						<AgGridReact
							defaultColDef={this.state.defaultColDef}
							columnDefs={this.state.columnData}
							rowData={rowData}
							rowSelection="multiple"
							suppressMenuHide={true}
							frameworkComponents={this.state.frameworkComponents}
							getRowHeight={this.state.getRowHeight}
							onGridReady={this.onGridReady}
							domLayout={this.state.domLayout}
							onGridSizeChanged={this.onGridSizeChanged.bind(this)}
							isExternalFilterPresent={this.isExternalFilterPresent}
							doesExternalFilterPass={this.doesExternalFilterPass}
							externalFilterChanged={this.externalFilterChanged}
						></AgGridReact>
					</div>
				</Paper>
			</div>
		);
	}
}

export default AgGridComponent;
